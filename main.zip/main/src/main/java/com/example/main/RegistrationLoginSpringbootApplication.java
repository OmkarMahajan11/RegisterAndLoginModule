package com.example.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationLoginSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationLoginSpringbootApplication.class, args);
	}

}
